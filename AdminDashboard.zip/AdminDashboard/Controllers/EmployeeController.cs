using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using AdminDashboard.Data;
using AdminDashboard.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using AdminDashboard.ViewModels;
using System.Linq;
using System;



namespace AdminDashboard.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string searchString, string sortOrder, int pageNumber = 1)
        {
            if (HttpContext.Session.GetString("Admin") == null)
                return RedirectToAction("Login", "Admin");

            int pageSize = 5;
            var employees = _context.Employees.AsQueryable();

            // SEARCH
            if (!string.IsNullOrEmpty(searchString))
            {
                employees = employees.Where(e =>
                    e.Name.Contains(searchString) ||
                    e.Username.Contains(searchString) ||
                    e.Position.Contains(searchString) ||
                    e.Department.Contains(searchString));
            }

            // SORT
            ViewData["NameSort"] = sortOrder == "name_asc" ? "name_desc" : "name_asc";
            switch (sortOrder)
            {
                case "name_desc":
                    employees = employees.OrderByDescending(e => e.Name);
                    break;
                case "name_asc":
                    employees = employees.OrderBy(e => e.Name);
                    break;
                default:
                    employees = employees.OrderBy(e => e.Id);
                    break;
            }

            // PAGINATION
            int totalRecords = await employees.CountAsync();
            var items = await employees
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var viewModel = new EmployeeListViewModel
            {
                Employees = items,
                SearchString = searchString,
                SortOrder = sortOrder,
                PageNumber = pageNumber,
                TotalPages = (int)Math.Ceiling((double)totalRecords / pageSize)
            };

            return View(viewModel);
        }

        [HttpGet]
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("Admin") == null)
                return RedirectToAction("Login", "Admin");

            return View();
        }

        [HttpPost]
        public IActionResult Create(Employee employee)
        {
            if (HttpContext.Session.GetString("Admin") == null)
                return RedirectToAction("Login", "Admin");

            _context.Employees.Add(employee);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Details(int id)
        {
            if (HttpContext.Session.GetString("Admin") == null)
                return RedirectToAction("Login", "Admin");

            var employee = _context.Employees.Find(id);
            if (employee == null)
                return NotFound();

            return View(employee);
        }


        public IActionResult Delete(int id)
        {
            if (HttpContext.Session.GetString("Admin") == null)
                return RedirectToAction("Login", "Admin");

            var employee = _context.Employees.Find(id);
            if (employee != null)
            {
                _context.Employees.Remove(employee);
                _context.SaveChanges();
            }

            return RedirectToAction("Index");
        }
    }
}
