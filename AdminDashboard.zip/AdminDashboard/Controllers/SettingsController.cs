using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace AdminDashboard.Controllers
{
    public class SettingsController : Controller
    {
        public IActionResult Index()
        {
            var theme = HttpContext.Session.GetString("Theme") ?? "light";
            ViewBag.Theme = theme;
            return View();
        }

        [HttpPost]
        public IActionResult ChangeTheme(string selectedTheme)
        {
            HttpContext.Session.SetString("Theme", selectedTheme);
            return RedirectToAction("Index");
        }
    }
}
