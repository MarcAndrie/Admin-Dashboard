﻿using Microsoft.AspNetCore.Mvc;
using AdminDashboard.Data;
using AdminDashboard.Models;
using AdminDashboard.ViewModels;
using System.Linq;
using System;
using System.Globalization;

namespace AdminDashboard.Controllers
{
    public class LeaveController : Controller
    {
        private readonly ApplicationDbContext _context;

        public LeaveController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index(int employeeId = 1, int year = 2025)
        {
            var data = _context.LeaveCredits
                .Where(l => l.EmployeeId == employeeId && l.Year == year)
                .ToList()
                .OrderBy(l => DateTime.ParseExact(l.Month, "MMMM", CultureInfo.InvariantCulture))
                .ToList(); 

            var viewModel = new LeaveCreditsViewModel
            {
                EmployeeId = employeeId,
                EmployeeName = _context.Employees.FirstOrDefault(e => e.Id == employeeId)?.Name ?? "Employee",
                Year = year,

                // Converts "January" → 1, "February" → 2, etc.
                Months = data.Select(d =>
                    DateTime.ParseExact(d.Month, "MMMM", CultureInfo.InvariantCulture).Month).ToList(),

                EarnedSick = data.Select(d => d.EarnedSickLeave).ToList(),
                UsedSick = data.Select(d => d.UsedSickLeave).ToList(),
                EarnedVacation = data.Select(d => d.EarnedVacationLeave).ToList(),
                UsedVacation = data.Select(d => d.UsedVacationLeave).ToList()
            };

            ViewBag.Employees = _context.Employees.ToList();

            return View(viewModel);
        }
    }
}
