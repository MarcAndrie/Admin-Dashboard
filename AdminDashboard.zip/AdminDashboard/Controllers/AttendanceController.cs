﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using AdminDashboard.Data;
using AdminDashboard.Models;
using AdminDashboard.ViewModels;
using System.Linq;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;


namespace AdminDashboard.Controllers
{
    public class AttendanceController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AttendanceController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ✅ Index Page with Search, Sort, Filter, and Pagination
        public async Task<IActionResult> Index(string searchString, string sortOrder, int? year, int? month, int pageNumber = 1)
        {
            int pageSize = 5;

            var query = _context.Attendance
                .Include(a => a.Employee)
                .Include(a => a.PayrollPeriod)
                .AsQueryable();

            // 🔍 Filter by year/month
            if (year.HasValue)
                query = query.Where(a => a.PayrollPeriod.Year == year.Value);
            if (month.HasValue)
                query = query.Where(a => a.PayrollPeriod.Month == month.Value);

            // 🔍 Search
            if (!string.IsNullOrEmpty(searchString))
            {
                query = query.Where(a =>
                    a.Employee.Username.Contains(searchString) ||
                    a.Employee.Name.Contains(searchString));
            }

            // ↕️ Sort
            ViewData["EmployeeSort"] = sortOrder == "emp_asc" ? "emp_desc" : "emp_asc";
            ViewData["NetSort"] = sortOrder == "net_asc" ? "net_desc" : "net_asc";

            switch (sortOrder)
            {
                case "emp_desc":
                    query = query.OrderByDescending(a => a.Employee.Username);
                    break;
                case "emp_asc":
                    query = query.OrderBy(a => a.Employee.Username);
                    break;
                case "net_asc":
                    query = query.OrderBy(a => a.NetSalary);
                    break;
                case "net_desc":
                    query = query.OrderByDescending(a => a.NetSalary);
                    break;
                default:
                    query = query.OrderByDescending(a => a.PayrollPeriod.PeriodDate);
                    break;
            }

            // 📄 Pagination
            int totalRecords = await query.CountAsync();
            var items = await query
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            // 📅 Dropdown values
            var years = await _context.PayrollPeriods.Select(p => p.Year).Distinct().OrderByDescending(y => y).ToListAsync();
            var months = await _context.PayrollPeriods.Select(p => p.Month).Distinct().OrderBy(m => m).ToListAsync();

            // 📦 ViewModel
            var viewModel = new AttendanceListViewModel
            {
                Records = items,
                SearchString = searchString,
                SortOrder = sortOrder,
                PageNumber = pageNumber,
                TotalPages = (int)Math.Ceiling((double)totalRecords / pageSize),
                SelectedYear = year,
                SelectedMonth = month,
                AvailableYears = years,
                AvailableMonths = months
            };

            return View(viewModel);
        }

        // ✅ Details page (charts)
        public IActionResult Details(int id, int? year, int? month)
        {
            // Redirect if not logged in (optional)
            if (HttpContext.Session.GetString("Admin") == null)
                return RedirectToAction("Login", "Admin");

            // Get all attendance records for the employee
            var records = _context.Attendance
                .Where(a => a.EmployeeId == id)
                .Include(a => a.Employee)
                .Include(a => a.PayrollPeriod)
                .AsQueryable();

            // Filter by year and/or month if provided
            if (year.HasValue)
            {
                records = records.Where(a => a.PayrollPeriod.Year == year.Value);
            }

            if (month.HasValue)
            {
                records = records.Where(a => a.PayrollPeriod.Month == month.Value);
            }

            var data = records
                .OrderBy(a => a.PayrollPeriod.PeriodDate)
                .ToList();

            if (!data.Any())
                return NotFound("No attendance data found for the selected filters.");

            var viewModel = new AttendanceChartViewModel
            {
                EmployeeName = data.First().Employee?.Name ?? "Employee",

                PayrollPeriods = data.Select(r =>
                    r.PayrollPeriod.PeriodDate.ToString("MMM dd") + " (" + r.PayrollPeriod.Cutoff + ")").ToList(),

                NetSalaries = data.Select(r => r.NetSalary).ToList(),
                GrossSalaries = data.Select(r => r.GrossSalary).ToList(),
                SSS = data.Select(r => r.SSS).ToList(),
                Pagibig = data.Select(r => r.Pagibig).ToList(),
                PhilHealth = data.Select(r => r.PhilHealth).ToList(),
                Deductions = data.Select(r => r.Deductions).ToList(),
                Lates = data.Select(r => r.Late).ToList(),
                Absences = data.Select(r => r.Absences).ToList()
            };

            return View(viewModel);
        }
    }
}
