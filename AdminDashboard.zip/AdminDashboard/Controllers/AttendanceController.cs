using Microsoft.AspNetCore.Mvc;
using AdminDashboard.Data;                
using AdminDashboard.Models;              
using AdminDashboard.ViewModels;          
using System.Linq;                        
using System.Collections.Generic;


namespace AdminDashboard.Controllers
{
    public class AttendanceController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AttendanceController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var records = _context.Attendance.ToList();
            return View(records);
        }

        // Show the chart page
        public IActionResult Details(int id)
        {
            // Get all attendance records for this employee
            var records = _context.Attendance
                .Where(a => a.EmployeeId == id)
                .OrderBy(a => a.PayrollPeriod)
                .ToList();

            if (records.Count == 0)
                return NotFound(); // no records for this employee

            var employeeName = _context.Employees
                .FirstOrDefault(e => e.Id == id)?.Name ?? "Employee";

            // Create the ViewModel
            var viewModel = new AttendanceChartViewModel
            {
                EmployeeName = employeeName,
                PayrollPeriods = records.Select(r => r.PayrollPeriod.ToString("MMM dd")).ToList(),
                NetSalaries = records.Select(r => r.NetSalary).ToList(),
                GrossSalaries = records.Select(r => r.GrossSalary).ToList(),
                SSS = records.Select(r => r.SSS).ToList(),
                Pagibig = records.Select(r => r.Pagibig).ToList(),
                PhilHealth = records.Select(r => r.PhilHealth).ToList(),
                Deductions = records.Select(r => r.Deductions).ToList(),
                Lates = records.Select(r => r.Late).ToList(),
                Absences = records.Select(r => r.Absences).ToList()
            };

            // Send ViewModel to the View
            return View(viewModel);
        }
    }
}
