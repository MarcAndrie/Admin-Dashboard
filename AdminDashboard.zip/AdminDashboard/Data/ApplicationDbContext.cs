using Microsoft.EntityFrameworkCore;
using AdminDashboard.Models;


namespace AdminDashboard.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Admin> Admins { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Attendance> Attendance { get; set; }
        public DbSet<LeaveCredit> LeaveCredits { get; set; }
    }
}