using System.Collections.Generic;
using AdminDashboard.Models;

namespace AdminDashboard.ViewModels
{
    public class AttendanceListViewModel
    {
        public List<Attendance> Records { get; set; }
        public string SearchString { get; set; }
        public string SortOrder { get; set; }
        public int PageNumber { get; set; }
        public int TotalPages { get; set; }
        public int? SelectedYear { get; set; }
        public int? SelectedMonth { get; set; }
        public List<int> AvailableYears { get; set; }
        public List<int> AvailableMonths { get; set; }
    }
}
