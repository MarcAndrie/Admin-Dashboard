using System.Collections.Generic;


namespace AdminDashboard.ViewModels
{
    public class AttendanceChartViewModel
    {
        public List<string> PayrollPeriods { get; set; }
        public List<decimal> NetSalaries { get; set; }
        public List<decimal> GrossSalaries { get; set; }
        public List<decimal> SSS { get; set; }
        public List<decimal> Pagibig { get; set; }
        public List<decimal> PhilHealth { get; set; }
        public List<decimal> Deductions { get; set; }
        public List<int> Lates { get; set; }
        public List<int> Absences { get; set; }

        public string EmployeeName { get; set; } // For display at top
    }
}
