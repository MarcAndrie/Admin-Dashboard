using System.Collections.Generic;
using System.Linq;

namespace AdminDashboard.ViewModels
{
    public class LeaveCreditsViewModel
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public int Year { get; set; }

        public List<int> Months { get; set; } = new List<int>();
        public List<int> EarnedSick { get; set; } = new List<int>();
        public List<int> UsedSick { get; set; } = new List<int>();
        public List<int> EarnedVacation { get; set; } = new List<int>();
        public List<int> UsedVacation { get; set; } = new List<int>();

        public int TotalEarnedSick => EarnedSick?.Sum() ?? 0;
        public int TotalUsedSick => UsedSick?.Sum() ?? 0;
        public int TotalEarnedVacation => EarnedVacation?.Sum() ?? 0;
        public int TotalUsedVacation => UsedVacation?.Sum() ?? 0;
    }
}
