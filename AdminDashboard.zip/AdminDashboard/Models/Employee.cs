using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdminDashboard.Models
{
    [Table("employees")]
    public class Employee
    {
        public int Id { get; set; }

        public string Username { get; set; }

        public string Name { get; set; }

        public int Age { get; set; }

        public string Address { get; set; }

        [Column("date_of_birth")]
        public DateTime DateOfBirth { get; set; }

        [Column("place_of_birth")]
        public string PlaceOfBirth { get; set; }

        public string Status { get; set; }

        public string Position { get; set; }

        public string Department { get; set; }

        [Column("date_hired")]
        public DateTime DateHired { get; set; }
    }
}
