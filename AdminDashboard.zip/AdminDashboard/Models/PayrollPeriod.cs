using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdminDashboard.Models
{
    [Table("payroll_periods")]
    public class PayrollPeriod
    {
        public int Id { get; set; }
        public int Year { get; set; }
        public int Month { get; set; }

        [Column("cutoff")]
        public string Cutoff { get; set; }

        [Column("period_date")]
        public DateTime PeriodDate { get; set; }

        public string Label { get; set; } 
    }
}
