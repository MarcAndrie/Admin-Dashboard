using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdminDashboard.Models
{
    public class Attendance
    {
        public int Id { get; set; }

        [Column("employee_id")]
        public int EmployeeId { get; set; }

        [ForeignKey("EmployeeId")]
        public Employee Employee { get; set; }

        public string Username { get; set; }

        [Column("payroll_period")]
        public DateTime PayrollPeriod { get; set; }

        [Column("gross_salary")]
        public decimal GrossSalary { get; set; }

        public decimal SSS { get; set; }
        public decimal Pagibig { get; set; }
        public decimal PhilHealth { get; set; }
        public decimal Deductions { get; set; }

        [Column("net_salary")]
        public decimal NetSalary { get; set; }

        [Column("time_sched")]
        public string Time_Sched { get; set; }

        public int Late { get; set; }
        public int Absences { get; set; }
    }
}
