namespace AdminDashboard.Models
{
    public class LeaveCredit
    {
        public int Id { get; set; }
        public int Employee_Id { get; set; }
        public string Month { get; set; }
        public int Year { get; set; }
        public int Earned_Sick_Leave { get; set; }
        public int Earned_Vacation_Leave { get; set; }
        public int Used_Leave { get; set; }

        public Employee Employee { get; set; } // Navigation property
    }
}
