using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdminDashboard.Models
{
    public class LeaveCredit
    {
        public int Id { get; set; }

        [Column("employee_id")]
        public int EmployeeId { get; set; }

        [ForeignKey("EmployeeId")]
        public Employee Employee { get; set; }

        public string Month { get; set; } 
        public int Year { get; set; }

        [Column("earned_sick_leave")]
        public int EarnedSickLeave { get; set; }

        [Column("used_sick_leave")]
        public int UsedSickLeave { get; set; }

        [Column("earned_vacation_leave")]
        public int EarnedVacationLeave { get; set; }

        [Column("used_vacation_leave")]
        public int UsedVacationLeave { get; set; }
    }
}
